<html>
<head>
	<title>Add Data</title>
</head>

<body>
<?php
//including the database connection file
include_once("conn.php");

if(isset($_POST['Submit'])) {	
	$id_car = mysqli_real_escape_string($conn, $_POST['id_car']);
	$namecarcare = mysqli_real_escape_string($conn, $_POST['namecarcare']);
	$phone = mysqli_real_escape_string($conn, $_POST['phone']);
	$address = mysqli_real_escape_string($conn, $_POST['address']);
	$latitude = mysqli_real_escape_string($conn, $_POST['latitude']);
	$longitude = mysqli_real_escape_string($conn, $_POST['longitude']);
		
	// checking empty fields
	if(empty($namecarcare) || empty($phone ) || empty($address) || empty($latitude) || empty($longitude)) {


		if(empty($namecarcare)) {
			echo "<font color='red'>NameCarcare field is empty.</font><br/>";
		}
        if(empty($phone)) {
			echo "<font color='red'>Phone field is empty.</font><br/>";
        }
        
		if(empty($address)) {
			echo "<font color='red'>Address field is empty.</font><br/>";
		}
		
		if(empty($latitude)) {
			echo "<font color='red'>Latitude field is empty.</font><br/>";
		}
		if(empty($longitude)) {
			echo "<font color='red'>Longtitude field is empty.</font><br/>";
        }
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
		// if all the fields are filled (not empty) 
			
		//insert data to database	
		
		$result = mysqli_query($conn, "INSERT INTO carcare(namecarcare,phone,address,latitude,longitude) VALUES('$namecarcare','$phone','$address','$latitude','$longitude')");
		
		//display success message
		echo "<font color='green'>Data added successfully.";
		echo "<br/><a href='listcarcare_admin.php'>View Result</a>";
	}
}
header('location:listcarcare_admin.php');
?>
</body>
</html>
