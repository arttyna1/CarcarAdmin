<?php
	include('conn.php');
	
	$id = $_GET['id'];
	$namecarcare = $_POST['namecarcare'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];
	
		//updating the table
		mysqli_query($conn, "update carcare set namecarcare='$namecarcare',address='$address',phone='$phone',latitude='$latitude',longitude='$longitude' where id_car='$id'");//แก้ตรง id_car >> id ถึงจะเชื่อมข้อมุลได้

		header("Location: listcarcare_admin.php");
?>