<?php>
	include('conn.php');
	
	$id_care = $_GET['id_care'];
	
	$status = $_POST['status'];
	
	
		//updating the table
		mysqli_query($conn, "UPDATE usercare SET status='$status' WHERE id_care=$id_care");
		
		//redirectig to the display page. In our case, it is index.php
		header("Location: allow_admin.php");
	
?>